#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "lexer.h"
#include "parser2.h"

int iTk;	// the iterator in tokens
Token* consumed;	// the last consumed token

// same as err, but also prints the line of the current token
_Noreturn; void tkerr(const char* fmt, ...) {
	fprintf(stderr, "error in line %d: ", tokens[iTk].line);
	va_list va;
	va_start(va, fmt);
	vfprintf(stderr, fmt, va);
	va_end(va);
	fprintf(stderr, "\n");
	exit(EXIT_FAILURE);
}


bool consume(int code) {
	printf("consume (%s)", tkCodeName(code));

	if (tokens[iTk].code == code) {	// if the current token is of type code
		consumed = &tokens[iTk++];	// set consumed to the current token and increment iTk
		printf(" => consumed\n");
		return true;
	}

	printf(" => found %s\n", tkCodeName(tokens[iTk].code));
	return false;
}

void parse() {
	iTk = 0;
	program();
}

// program ::= ( defVar | defFunc | block )* FINISH
bool program() {
	printf("\n------- FIRS: program -------\n");

	while (true) {
		if (defVar()) {}
		else if(defFunc()){}
		else if(block()){}
		else break;
	}

	if (consume(FINISH)) {
		printf("\n------- Syntax = OK -------\n");
		return false;
	}
	else tkerr("syntax error");
	
	return false;
}


// defVar ::= VAR ID COLON baseType SEMICOLON
bool defVar() {

	printf("\n------- FIRS: defVar -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(VAR)) {
		if (consume(ID)) {
			if (consume(COLON)) {
				if (baseType()) {
					if (consume(SEMICOLON)) {
						return true;
					}
					else tkerr("syntax error: missing ';' after [base type]");
				}
				else tkerr("syntax error: missing [base type] after ':'");
			}
			else tkerr("syntax error: missing ':' after [identifier]");
		}
		else tkerr("syntax error: missing [identifier] after 'var'");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// baseType ::= TYPE_INT | TYPE_REAL | TYPE_STR
bool baseType() {

	printf("\n------- FIRS: baseType -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(TYPE_INT)) { return true; }
	else if (consume(TYPE_REAL)) { return true; }
	else if (consume(TYPE_STR)) { return true; }
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// defFunc ::= FUNCTION ID LPAR funcParams? RPAR COLON basetype defVar* block END
bool defFunc() {

	printf("\n------- FIRS: defFunc -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(FUNCTION)) {
		if (consume(ID)) {
			if (consume(LPAR)) {
				if (funcParams()) {}
					if (consume(RPAR)) {
						if (consume(COLON)) {
							if (baseType()) {
								while (defVar()) {}
								if (block()) {
									if (consume(END)) {
										return true;
									}
									else tkerr("syntax error: missing 'end' after [block]");
								}
								else tkerr("syntax error: missing [block] after [base type]");
							}
							else tkerr("syntax error: missing [base type] after ':'");
						}
						else tkerr("syntax error: missing ':' after ')'");
					}
					else tkerr("syntax error: missing ')' after [function parameters]");
				
			}
			else tkerr("syntax error: missing '(' after [identifier]");
		}
		else tkerr("syntax error: missing [identifier] after 'function'");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// funcParams ::= funcParam ( COMMA funcParam )*
bool funcParams() {

	printf("\n------- FIRS: funcParams -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (funcParam()) {
		while (consume(COMMA)) {
			if (funcParam()) {}
			else tkerr("syntax error: missing [function parameter] after ','");
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// funcParam ::= ID COLON baseType
bool funcParam() {

	printf("\n------- FIRS: funcParam -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(ID)) {
		if (consume(COLON)) {
			if (baseType()) {
				return true;
			}
			else tkerr("syntax error: missing [base type] after ':'");
		}
		else tkerr("syntax error: missing ':' after [identifier]");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// block ::= instr+
bool block() {

	printf("\n------- FIRS: block -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (instr()) {
		while (instr()) {}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// instr ::=  exprLogic? SEMICOLON 
//			| IF LPAR exprLogic RPAR block ( ELSE block )? END 
//			| RETURN exprLogic SEMICOLON
//			| WHILE LPAR exprLogic RPAR block END
bool instr() {
	printf("\n------- FIRS: instr -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprLogic()) {
		if (consume(SEMICOLON)) { return true; }
		else { tkerr("syntax error: missing ';' after [expression]"); }
	}
	else if (consume(SEMICOLON)) { return true; }
	else if (consume(IF)) {
		if (consume(LPAR)) {
			if (exprLogic()) {
				if (consume(RPAR)) {
					if (block()) {
						if (consume(ELSE)) {
							if (block()) {}
							else { tkerr("syntax error: missing [block] after 'else'"); }
						}
						if (consume(END)) { return true; }
						else { tkerr("syntax error: missing 'end' after [block]"); }
					}
					else { tkerr("syntax error: missing [block] after ')'"); }
				}
				else { tkerr("syntax error: missing ')' after [expression]"); }
			}
			else { tkerr("syntax error: missing [expression] after '('"); }
		}
		else { tkerr("syntax error: missing '(' after 'if'"); }
	}
	else if (consume(RETURN)) {
		if (exprLogic()) {
			if (consume(SEMICOLON)) {
				return true;
			}
			else { tkerr("syntax error: missing ';' after [expression]"); }
		}
		else { tkerr("syntax error: missing [expression] after 'return'"); }
	}
	else if (consume(WHILE)) {
		if (consume(LPAR)) {
			if (exprLogic()) {
				if (consume(RPAR)) {
					if (block()) {
						if (consume(END)) { return true; }
						else { tkerr("syntax error: missing 'end' after [block]"); }
					}
					else { tkerr("syntax error: missing [block] after ')'"); }
				}
				else { tkerr("syntax error: missing ')' after [expression]"); }
			}
			else { tkerr("syntax error: missing [expression] after '('"); }
		}
		else { tkerr("syntax error: missing '(' after 'while'"); }
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// exprLogic ::= exprAssign ( (AND | OR ) exprAssign )*
bool exprLogic() {
	printf("\n------- FIRS: exprLogic -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprAssign()) {
		while (consume(AND) || consume(OR)) {
			int operator_code = consumed->code;
			if (exprAssign()) {}
			else {
				switch (operator_code)
				{
					case AND:
						tkerr("syntax error: missing [expression] after &&");
						break;

					case OR:
						tkerr("syntax error: missing [expression] after ||");
						break;

					default:
						tkerr("syntax error: FATAL");
						break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprAssign ::= ( ID ASSIGN )? exprComp
bool exprAssign() {
	printf("\n------- FIRS: exprAssign -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(ID)) {
		if (consume(ASSIGN)) {}
		else { 
			//tkerr("syntax error: missing '=' after [identifier]");
			// restore iTk
			iTk = start_iTk;
		}
	}

	if (exprComp()) {
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprComp ::= exprAdd ( (LESS | EQUAL) exprAdd )?
bool exprComp() {
	printf("\n------- FIRS: exprComp -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprAdd()) {
		if (consume(LESS) || consume(EQUAL)) {
			int operator_code = consumed->code;
			if (exprAdd()) {}
			else {
				switch (operator_code)
				{
				case LESS:
					tkerr("syntax error: missing [expression] after '<'");
					break;

				case EQUAL:
					tkerr("syntax error: missing [expression] after '=='");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprAdd ::= exprMul ( (ADD | SUB) exprMul )*
bool exprAdd() {
	printf("\n------- FIRS: exprAdd -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprMul()) {
		while (consume(ADD) || consume(SUB)) {
			int operator_code = consumed->code;
			if (exprMul()) {}
			else {
				switch (operator_code)
				{
				case ADD:
					tkerr("syntax error: missing [expression] after '+'");
					break;

				case SUB:
					tkerr("syntax error: missing [expression] after '-'");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprMul ::= exprPrefix ( (MUL | DIV) exprPrefix )*
bool exprMul() {
	printf("\n------- FIRS: exprMul -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprPrefix()) {
		while (consume(MUL) || consume(DIV)) {
			int operator_code = consumed->code;
			if (exprPrefix()) {}
			else {
				switch (operator_code)
				{
				case MUL:
					tkerr("syntax error: missing [expression] after '*'");
					break;

				case DIV:
					tkerr("syntax error: missing [expression] after '/'");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}

		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprPrefix ::= ( SUB | NOT )? factor
bool exprPrefix() {
	printf("\n------- FIRS: exprPrefix -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	bool found_sub_or_not = false;
	int operator_code;

	if (consume(SUB) || consume(NOT)) { 
		found_sub_or_not = true; 
		operator_code = consumed->code; 
	}

	if (found_sub_or_not) {
		if (factor()) { return true; }
		else {
			switch (operator_code)
			{
			case SUB:
				tkerr("syntax error: missing [factor] after '-'");
				break;

			case NOT:
				tkerr("syntax error: missing [factor] after '!'");
				break;

			default:
				tkerr("syntax error: FATAL");
				break;
			}
		}
	}
	else if (factor()) { return true; }
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// factor ::= INT 
//			| REAL 
//			| STR 
//			| LPAR exprLogic RPAR
//			| ID ( LPAR ( exprLogic ( COMMA exprLogic )* )? RPAR )?
bool factor() {
	printf("\n------- FIRS: factor -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(INT)) { return true; }
	else if (consume(REAL)) { return true; }
	else if (consume(STR)) { return true; }
	else if (consume(LPAR)) {
		if (exprLogic()) {
			if (consume(RPAR)) { return true; }
			else tkerr("syntax error: missing ')' after [expression]");
		}
		else tkerr("syntax error: missing [expression] after '('");
	}
	else if (consume(ID)) {
		if (consume(LPAR)) {
			if (exprLogic()) {
				while (consume(COMMA)) {
					if (exprLogic()) {}
					else tkerr("syntax error: missing [expression] after ','");
				}
			}
			if (consume(RPAR)) { return true; }
			else tkerr("syntax error: missing ')' after [expression]");
		}
		else return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

