#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "lexer.h"
#include "parser2.h"
#include "ad.h"
#include "at.h"

int iTk;	// the iterator in tokens
Token* consumed;	// the last consumed token

// same as err, but also prints the line of the current token
_Noreturn; void tkerr(const char* fmt, ...) {
	fprintf(stderr, "error in line %d: ", tokens[iTk].line);
	va_list va;
	va_start(va, fmt);
	vfprintf(stderr, fmt, va);
	va_end(va);
	fprintf(stderr, "\n");
	exit(EXIT_FAILURE);
}


bool consume(int code) {
	printf("consume (%s)", tkCodeName(code));

	if (tokens[iTk].code == code) {	// if the current token is of type code
		consumed = &tokens[iTk++];	// set consumed to the current token and increment iTk
		printf(" => consumed\n");
		return true;
	}

	printf(" => found %s\n", tkCodeName(tokens[iTk].code));
	return false;
}

void parse() {
	iTk = 0;
	program();
}

// program ::= ( defVar | defFunc | block )* FINISH
bool program() {
	printf("\n------- FIRS: program -------\n");
	
	addDomain(); // create global domain

	addPredefinedFns();	// add predefined functions

	while (true) {
		if (defVar()) {}
		else if(defFunc()){}
		else if(block()){}
		else break;
	}

	if (consume(FINISH)) {
		delDomain(); // delete global domain
		printf("\n------- Syntax = OK -------\n");
		return false;
	}
	else tkerr("syntax error");
	
	return false;
}


// defVar ::= VAR ID COLON baseType SEMICOLON
bool defVar() {

	printf("\n------- FIRS: defVar -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(VAR)) {
		if (consume(ID)) {
			const char* name = consumed->text;
			Symbol* s = searchInCurrentDomain(name);
			if (s) tkerr("domain error: variable redefinition: %s", name);
			s = addSymbol(name, KIND_VAR);
			s->local = crtFn != NULL;
			if (consume(COLON)) {
				if (baseType()) {
					s->type = ret.type;
					if (consume(SEMICOLON)) {
						return true;
					}
					else tkerr("syntax error: missing ';' after [base type]");
				}
				else tkerr("syntax error: missing [base type] after ':'");
			}
			else tkerr("syntax error: missing ':' after [identifier]");
		}
		else tkerr("syntax error: missing [identifier] after 'var'");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// baseType ::= TYPE_INT | TYPE_REAL | TYPE_STR
bool baseType() {

	printf("\n------- FIRS: baseType -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(TYPE_INT)) { 
		ret.type = TYPE_INT; 
		return true; 
	}
	else if (consume(TYPE_REAL)) { 
		ret.type = TYPE_REAL;
		return true; 
	}
	else if (consume(TYPE_STR)) { 
		ret.type = TYPE_STR;
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// defFunc ::= FUNCTION ID LPAR funcParams RPAR COLON basetype defVar* block END
bool defFunc() {

	printf("\n------- FIRS: defFunc -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(FUNCTION)) {
		if (consume(ID)) {
			const char* name = consumed->text;
			Symbol* s = searchInCurrentDomain(name);
			if (s) tkerr("function redefinition: %s", name);

			crtFn = addSymbol(name, KIND_FN);
			crtFn->args = NULL;
			addDomain();// create local domain

			if (consume(LPAR)) {
				if (funcParams()) {
					if (consume(RPAR)) {
						if (consume(COLON)) {
							if (baseType()) {
								crtFn->type = ret.type;
								while (defVar()) {}
								if (block()) {
									if (consume(END)) {
										delDomain();	// delete local domain
										crtFn = NULL;
										return true;
									}
									else tkerr("syntax error: missing 'end' after [block]");
								}
								else tkerr("syntax error: missing [block] after [base type]");
							}
							else tkerr("syntax error: missing [base type] after ':'");
						}
						else tkerr("syntax error: missing ':' after ')'");
					}
					else tkerr("syntax error: missing ')' after [function parameters]");
				}
				else tkerr("syntax error: missing [function parameters] after '('");
			}
			else tkerr("syntax error: missing '(' after [identifier]");
		}
		else tkerr("syntax error: missing [identifier] after 'function'");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// funcParams ::= ( funcParam (COMMA funcParam)* )?
bool funcParams() {

	printf("\n------- FIRS: funcParams -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (funcParam()) {
		if (consume(COMMA)) {
			if (funcParam()) {
				while (consume(COMMA)) {
					if (funcParam()) {}
					else tkerr("syntax error: missing [function parameter] after ','");
				}
			}
		}
	}

	// restore iTk
	// iTk = start_iTk;
	return true;	// returns always true
}

// funcParam ::= ID COLON baseType
bool funcParam() {

	printf("\n------- FIRS: funcParam -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(ID)) {
		const char* name = consumed->text;
		Symbol* s = searchInCurrentDomain(name);
		if (s) tkerr("domain error: function argument redefinition: %s", name);
		s = addSymbol(name, KIND_ARG);
		Symbol* sFnParam = addFnArg(crtFn, name);
		if (consume(COLON)) {
			if (baseType()) {
				s->type = ret.type;
				sFnParam->type = ret.type;
				return true;
			}
			else tkerr("syntax error: missing [base type] after ':'");
		}
		else tkerr("syntax error: missing ':' after [identifier]");
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// block ::= instr+
bool block() {

	printf("\n------- FIRS: block -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (instr()) {
		while (instr()) {}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// instr ::=  exprLogic? SEMICOLON 
//			| IF LPAR exprLogic RPAR block ( ELSE block )? END 
//			| RETURN exprLogic SEMICOLON
//			| WHILE LPAR exprLogic RPAR block END
bool instr() {
	printf("\n------- FIRS: instr -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprLogic()) {
		if (consume(SEMICOLON)) { return true; }
		else { tkerr("syntax error: missing ';' after [expression]"); }
	}
	else if (consume(SEMICOLON)) { return true; }
	else if (consume(IF)) {
		if (consume(LPAR)) {
			if (exprLogic()) {
				if (ret.type == TYPE_STR)tkerr("type error: the if condition must have type int or real");
				if (consume(RPAR)) {
					if (block()) {
						if (consume(ELSE)) {
							if (block()) {}
							else { tkerr("syntax error: missing [block] after 'else'"); }
						}
						if (consume(END)) { return true; }
						else { tkerr("syntax error: missing 'end' after [block]"); }
					}
					else { tkerr("syntax error: missing [block] after ')'"); }
				}
				else { tkerr("syntax error: missing ')' after [expression]"); }
			}
			else { tkerr("syntax error: missing [expression] after '('"); }
		}
		else { tkerr("syntax error: missing '(' after 'if'"); }
	}
	else if (consume(RETURN)) {
		if (exprLogic()) {
			if (!crtFn) tkerr("type error: return can be used only in a function");
			if (ret.type != crtFn->type) tkerr("type error: the return type must be the same as the function return type");
			if (consume(SEMICOLON)) {
				return true;
			}
			else { tkerr("syntax error: missing ';' after [expression]"); }
		}
		else { tkerr("syntax error: missing [expression] after 'return'"); }
	}
	else if (consume(WHILE)) {
		if (consume(LPAR)) {
			if (exprLogic()) {
				if (ret.type == TYPE_STR) tkerr("type error: the while condition must have type int or real");
				if (consume(RPAR)) {
					if (block()) {
						if (consume(END)) { return true; }
						else { tkerr("syntax error: missing 'end' after [block]"); }
					}
					else { tkerr("syntax error: missing [block] after ')'"); }
				}
				else { tkerr("syntax error: missing ')' after [expression]"); }
			}
			else { tkerr("syntax error: missing [expression] after '('"); }
		}
		else { tkerr("syntax error: missing '(' after 'while'"); }
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// exprLogic ::= exprAssign ( (AND | OR ) exprAssign )*
bool exprLogic() {
	printf("\n------- FIRS: exprLogic -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprAssign()) {
		while (consume(AND) || consume(OR)) {
			int operator_code = consumed->code;

			Ret leftType = ret;
			if (leftType.type == TYPE_STR)tkerr("type error: the left operand of && or || cannot be of type str");
			
			if (exprAssign()) {
				if (ret.type == TYPE_STR)tkerr("type error: the right operand of && or || cannot be of type str");
				setRet(TYPE_INT, false);
			}
			else {
				switch (operator_code)
				{
					case AND:
						tkerr("syntax error: missing [expression] after &&");
						break;

					case OR:
						tkerr("syntax error: missing [expression] after ||");
						break;

					default:
						tkerr("syntax error: FATAL");
						break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprAssign ::= ID ASSIGN exprComp
//					| exprComp
bool exprAssign() {
	printf("\n------- FIRS: exprAssign -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(ID)) {
		const char* name = consumed->text;
		if (consume(ASSIGN)) {
			if (exprComp()) {
				Symbol* s = searchSymbol(name);
				if (!s) tkerr("type error: undefined symbol: %s", name);
				if (s->kind == KIND_FN) tkerr("type error: a function (%s) cannot be used as a destination for assignment ", name);
				if (s->type != ret.type) tkerr("type error: the source and destination for assignment must have the same type");
				ret.lval = false;

				return true;
			}
			else { tkerr("syntax error: missing [expression] after '='"); }
		}
		else { tkerr("syntax error: missing '=' after [identifier]"); }
	}
	else if (exprComp()) { 
		return true; 
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprComp ::= exprAdd ( (LESS | EQUAL) exprAdd )?
bool exprComp() {
	printf("\n------- FIRS: exprComp -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprAdd()) {
		if (consume(LESS) || consume(EQUAL)) {
			int operator_code = consumed->code;
			Ret leftType = ret;
			if (exprAdd()) {
				if (leftType.type != ret.type) tkerr("type error: different types for the operands of < or ==");
				setRet(TYPE_INT, false); // the result of comparation is int 0 or 1
			}
			else {
				switch (operator_code)
				{
				case LESS:
					tkerr("syntax error: missing [expression] after '<'");
					break;

				case EQUAL:
					tkerr("syntax error: missing [expression] after '=='");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprAdd ::= exprMul ( (ADD | SUB) exprMul )*
bool exprAdd() {
	printf("\n------- FIRS: exprAdd -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprMul()) {
		while (consume(ADD) || consume(SUB)) {
			int operator_code = consumed->code;
			Ret leftType = ret;
			if (leftType.type == TYPE_STR) tkerr("type error: the operands of + or - cannot be of type str");
			if (exprMul()) {
				if (leftType.type != ret.type) tkerr("type error: different types for the operands of + or -");
				ret.lval = false;
			}
			else {
				switch (operator_code)
				{
				case ADD:
					tkerr("syntax error: missing [expression] after '+'");
					break;

				case SUB:
					tkerr("syntax error: missing [expression] after '-'");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprMul ::= exprPrefix ( (MUL | DIV) exprPrefix )*
bool exprMul() {
	printf("\n------- FIRS: exprMul -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (exprPrefix()) {
		while (consume(MUL) || consume(DIV)) {
			int operator_code = consumed->code;
			Ret leftType = ret;
			if (leftType.type == TYPE_STR) tkerr("type error: the operands of * or / cannot be of type str");
			if (exprPrefix()) {
				if (leftType.type != ret.type) tkerr("type error: different types for the operands of * or /");
				ret.lval = false;
			}
			else {
				switch (operator_code)
				{
				case MUL:
					tkerr("syntax error: missing [expression] after '*'");
					break;

				case DIV:
					tkerr("syntax error: missing [expression] after '/'");
					break;

				default:
					tkerr("syntax error: FATAL");
					break;
				}
			}
		}

		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

// exprPrefix ::= SUB factor
//					| NOT factor 
//					| factor
bool exprPrefix() {
	printf("\n------- FIRS: exprPrefix -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(SUB)) {
		if (factor()) {
			if (ret.type == TYPE_STR) tkerr("type error: the expression of unary - must be of type int or real");
			ret.lval = false;

			return true;
		}
		else {
			tkerr("syntax error: missing [factor] after '-'");
		}
	}
	else if (consume(NOT)) {
		if (factor()) {
			if (ret.type == TYPE_STR) tkerr("type error: the expression of ! must be of type int or real");
			setRet(TYPE_INT, false);

			return true;
		}
		else {
			tkerr("syntax error: missing [factor] after '!'");
		}
	}
	else if (factor()) {
		return true;
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}


// factor ::= INT 
//			| REAL 
//			| STR 
//			| LPAR exprLogic RPAR
//			| ID ( LPAR ( exprLogic ( COMMA exprLogic )* )? RPAR | epsilon )
bool factor() {
	printf("\n------- FIRS: factor -------\n");

	// memorize the current value of iTk
	int start_iTk = iTk;

	if (consume(INT)) { 
		setRet(TYPE_INT, false);
		return true;
	}
	else if (consume(REAL)) { 
		setRet(TYPE_REAL, false);
		return true;
	}
	else if (consume(STR)) { 
		setRet(TYPE_STR, false);
		return true;
	}
	else if (consume(LPAR)) {
		if (exprLogic()) {
			if (consume(RPAR)) { return true; }
			else tkerr("syntax error: missing ')' after [expression]");
		}
		else tkerr("syntax error: missing [expression] after '('");
	}
	else if (consume(ID)) {
		Symbol* s = searchSymbol(consumed->text);
		if (!s) tkerr("type error: undefined symbol: %s", consumed->text);

		if (consume(LPAR)) {
			if (s->kind != KIND_FN )tkerr("type error: %s cannot be called, because it is not a function", s->name);
			Symbol* argDef = s->args;
			if (exprLogic()) {
				if (!argDef) tkerr("type error: the function %s is called with too many arguments", s->name);
				if (argDef->type != ret.type) tkerr("type error: the argument type at function %s call is different from the one given at its definition",s->name);
				argDef = argDef->next;

				while (consume(COMMA)) {
					if (exprLogic()) {
						if (!argDef) tkerr("type error: the function %s is called with too many arguments", s->name);
						if (argDef->type != ret.type) tkerr("type error: the argument type at function %s call is different from the one given at its definition",s->name);
						argDef = argDef->next;
					}
					else tkerr("syntax error: missing [expression] after ','");
				}
			}
			if (consume(RPAR)) { 
				if (argDef) {
					tkerr("type error: the function %s is called with too few arguments", s->name);
					setRet(s->type, false);
				}
				else if (s->kind == KIND_FN) {
					tkerr("the function %s can only be called", s->name);
					setRet(s->type, true);
				}
				
				return true;
			}
			else tkerr("syntax error: missing ')' after [expression]");
		}
	}
	else {
		// restore iTk
		iTk = start_iTk;
		return false;
	}
}

