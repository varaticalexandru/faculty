//p0.c

#include <stdlib.h>
#include <stdio.h>

int main() 
{
	printf("123!\n"); 
	return 0;
}
