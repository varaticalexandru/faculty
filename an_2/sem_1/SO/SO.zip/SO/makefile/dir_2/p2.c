//p1.c

#include <stdlib.h>
#include <stdio.h>

int main() 
{
	printf("1234 !\n"); 
	return 0;
}
