//p1.c

#include <stdlib.h>
#include <stdio.h>

int main() 
{
	printf("12 34!\n"); 
	return 0;
}
