#include "dependency.h"

void main()
{
    SayHello();
}
