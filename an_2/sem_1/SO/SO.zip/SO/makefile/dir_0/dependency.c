#include <stdio.h>

void SayHello(void)
{
    printf("Hello Lume\n");
}
