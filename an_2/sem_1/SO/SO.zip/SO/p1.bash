#!/bin/bash

clear

echo "$(pwd)"
