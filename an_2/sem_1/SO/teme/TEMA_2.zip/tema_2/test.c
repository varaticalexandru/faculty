#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

int main(int agrc, char** argv)
{
	symlink("/home/alexandru/Desktop/SO/teme/tema_2/f123", "/home/alexandru/Desktop/SO/teme/tema_2/f123_symlink");

	return 0;
}
