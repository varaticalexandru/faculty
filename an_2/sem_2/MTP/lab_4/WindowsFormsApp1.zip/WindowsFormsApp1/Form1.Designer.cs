﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.candidatLabel = new System.Windows.Forms.Label();
            this.candidatTextBox = new System.Windows.Forms.TextBox();
            this.idxIntrebareTextBox = new System.Windows.Forms.TextBox();
            this.nrIntrebareLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.intrebareLabel = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.punctajTextBox = new System.Windows.Forms.TextBox();
            this.punctajLabel = new System.Windows.Forms.Label();
            this.urmatoareaIntrebareButton = new System.Windows.Forms.Button();
            this.nrRaspCorecteTextBox = new System.Windows.Forms.TextBox();
            this.nrRaspCorectLabel = new System.Windows.Forms.Label();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.delimiterLabel = new System.Windows.Forms.Label();
            this.testTextBox = new System.Windows.Forms.TextBox();
            this.testLabel = new System.Windows.Forms.Label();
            this.afiseazaRaspunsButton = new System.Windows.Forms.Button();
            this.raspCorectTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // candidatLabel
            // 
            this.candidatLabel.AutoSize = true;
            this.candidatLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.candidatLabel.Location = new System.Drawing.Point(34, 64);
            this.candidatLabel.Name = "candidatLabel";
            this.candidatLabel.Size = new System.Drawing.Size(72, 17);
            this.candidatLabel.TabIndex = 0;
            this.candidatLabel.Text = "Candidat";
            // 
            // candidatTextBox
            // 
            this.candidatTextBox.Enabled = false;
            this.candidatTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.candidatTextBox.Location = new System.Drawing.Point(157, 61);
            this.candidatTextBox.Name = "candidatTextBox";
            this.candidatTextBox.Size = new System.Drawing.Size(187, 23);
            this.candidatTextBox.TabIndex = 1;
            // 
            // idxIntrebareTextBox
            // 
            this.idxIntrebareTextBox.Enabled = false;
            this.idxIntrebareTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idxIntrebareTextBox.Location = new System.Drawing.Point(157, 93);
            this.idxIntrebareTextBox.Name = "idxIntrebareTextBox";
            this.idxIntrebareTextBox.Size = new System.Drawing.Size(31, 23);
            this.idxIntrebareTextBox.TabIndex = 3;
            // 
            // nrIntrebareLabel
            // 
            this.nrIntrebareLabel.AutoSize = true;
            this.nrIntrebareLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nrIntrebareLabel.Location = new System.Drawing.Point(34, 96);
            this.nrIntrebareLabel.Name = "nrIntrebareLabel";
            this.nrIntrebareLabel.Size = new System.Drawing.Size(100, 17);
            this.nrIntrebareLabel.TabIndex = 2;
            this.nrIntrebareLabel.Text = "Nr. intrebarii";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(372, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(289, 157);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // intrebareLabel
            // 
            this.intrebareLabel.AutoSize = true;
            this.intrebareLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.intrebareLabel.Location = new System.Drawing.Point(34, 156);
            this.intrebareLabel.Name = "intrebareLabel";
            this.intrebareLabel.Size = new System.Drawing.Size(0, 17);
            this.intrebareLabel.TabIndex = 5;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(37, 196);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(385, 243);
            this.flowLayoutPanel1.TabIndex = 6;
            // 
            // punctajTextBox
            // 
            this.punctajTextBox.Enabled = false;
            this.punctajTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.punctajTextBox.Location = new System.Drawing.Point(561, 269);
            this.punctajTextBox.Name = "punctajTextBox";
            this.punctajTextBox.Size = new System.Drawing.Size(100, 23);
            this.punctajTextBox.TabIndex = 8;
            // 
            // punctajLabel
            // 
            this.punctajLabel.AutoSize = true;
            this.punctajLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.punctajLabel.Location = new System.Drawing.Point(439, 272);
            this.punctajLabel.Name = "punctajLabel";
            this.punctajLabel.Size = new System.Drawing.Size(62, 17);
            this.punctajLabel.TabIndex = 7;
            this.punctajLabel.Text = "Punctaj";
            // 
            // urmatoareaIntrebareButton
            // 
            this.urmatoareaIntrebareButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urmatoareaIntrebareButton.Location = new System.Drawing.Point(37, 461);
            this.urmatoareaIntrebareButton.Name = "urmatoareaIntrebareButton";
            this.urmatoareaIntrebareButton.Size = new System.Drawing.Size(157, 31);
            this.urmatoareaIntrebareButton.TabIndex = 9;
            this.urmatoareaIntrebareButton.Text = "Urmatoarea intrebare";
            this.urmatoareaIntrebareButton.UseVisualStyleBackColor = true;
            this.urmatoareaIntrebareButton.Click += new System.EventHandler(this.urmatoareaIntrebareButton_Click);
            // 
            // nrRaspCorecteTextBox
            // 
            this.nrRaspCorecteTextBox.Enabled = false;
            this.nrRaspCorecteTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nrRaspCorecteTextBox.Location = new System.Drawing.Point(561, 335);
            this.nrRaspCorecteTextBox.Name = "nrRaspCorecteTextBox";
            this.nrRaspCorecteTextBox.Size = new System.Drawing.Size(100, 23);
            this.nrRaspCorecteTextBox.TabIndex = 10;
            // 
            // nrRaspCorectLabel
            // 
            this.nrRaspCorectLabel.AutoSize = true;
            this.nrRaspCorectLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nrRaspCorectLabel.Location = new System.Drawing.Point(439, 320);
            this.nrRaspCorectLabel.Name = "nrRaspCorectLabel";
            this.nrRaspCorectLabel.Size = new System.Drawing.Size(85, 51);
            this.nrRaspCorectLabel.TabIndex = 11;
            this.nrRaspCorectLabel.Text = "Nr. \r\nraspunsuri\r\ncorecte";
            // 
            // totalTextBox
            // 
            this.totalTextBox.Enabled = false;
            this.totalTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalTextBox.Location = new System.Drawing.Point(212, 93);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(31, 23);
            this.totalTextBox.TabIndex = 12;
            // 
            // delimiterLabel
            // 
            this.delimiterLabel.AutoSize = true;
            this.delimiterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delimiterLabel.Location = new System.Drawing.Point(194, 96);
            this.delimiterLabel.Name = "delimiterLabel";
            this.delimiterLabel.Size = new System.Drawing.Size(12, 17);
            this.delimiterLabel.TabIndex = 13;
            this.delimiterLabel.Text = "/";
            // 
            // testTextBox
            // 
            this.testTextBox.Enabled = false;
            this.testTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.testTextBox.Location = new System.Drawing.Point(157, 26);
            this.testTextBox.Name = "testTextBox";
            this.testTextBox.Size = new System.Drawing.Size(187, 23);
            this.testTextBox.TabIndex = 15;
            // 
            // testLabel
            // 
            this.testLabel.AutoSize = true;
            this.testLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.testLabel.Location = new System.Drawing.Point(34, 29);
            this.testLabel.Name = "testLabel";
            this.testLabel.Size = new System.Drawing.Size(40, 17);
            this.testLabel.TabIndex = 14;
            this.testLabel.Text = "Test";
            // 
            // afiseazaRaspunsButton
            // 
            this.afiseazaRaspunsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.afiseazaRaspunsButton.Location = new System.Drawing.Point(265, 461);
            this.afiseazaRaspunsButton.Name = "afiseazaRaspunsButton";
            this.afiseazaRaspunsButton.Size = new System.Drawing.Size(157, 31);
            this.afiseazaRaspunsButton.TabIndex = 16;
            this.afiseazaRaspunsButton.Text = "Afiseaza raspunsul";
            this.afiseazaRaspunsButton.UseVisualStyleBackColor = true;
            this.afiseazaRaspunsButton.Click += new System.EventHandler(this.afiseazaRaspunsButton_Click);
            // 
            // raspCorectTextBox
            // 
            this.raspCorectTextBox.Enabled = false;
            this.raspCorectTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raspCorectTextBox.Location = new System.Drawing.Point(442, 465);
            this.raspCorectTextBox.Name = "raspCorectTextBox";
            this.raspCorectTextBox.Size = new System.Drawing.Size(219, 23);
            this.raspCorectTextBox.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 504);
            this.Controls.Add(this.raspCorectTextBox);
            this.Controls.Add(this.afiseazaRaspunsButton);
            this.Controls.Add(this.testTextBox);
            this.Controls.Add(this.testLabel);
            this.Controls.Add(this.delimiterLabel);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.nrRaspCorectLabel);
            this.Controls.Add(this.nrRaspCorecteTextBox);
            this.Controls.Add(this.urmatoareaIntrebareButton);
            this.Controls.Add(this.punctajTextBox);
            this.Controls.Add(this.punctajLabel);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.intrebareLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.idxIntrebareTextBox);
            this.Controls.Add(this.nrIntrebareLabel);
            this.Controls.Add(this.candidatTextBox);
            this.Controls.Add(this.candidatLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label candidatLabel;
        private System.Windows.Forms.TextBox candidatTextBox;
        private System.Windows.Forms.TextBox idxIntrebareTextBox;
        private System.Windows.Forms.Label nrIntrebareLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label intrebareLabel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox punctajTextBox;
        private System.Windows.Forms.Label punctajLabel;
        private System.Windows.Forms.Button urmatoareaIntrebareButton;
        private System.Windows.Forms.TextBox nrRaspCorecteTextBox;
        private System.Windows.Forms.Label nrRaspCorectLabel;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Label delimiterLabel;
        private System.Windows.Forms.TextBox testTextBox;
        private System.Windows.Forms.Label testLabel;
        private System.Windows.Forms.Button afiseazaRaspunsButton;
        private System.Windows.Forms.TextBox raspCorectTextBox;
    }
}

