﻿namespace ex_7
{
    partial class LPF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.echipaLabel = new System.Windows.Forms.Label();
            this.echipeComboBox = new System.Windows.Forms.ComboBox();
            this.adaugaEchipaButton = new System.Windows.Forms.Button();
            this.detaliiJucatorGroupBox = new System.Windows.Forms.GroupBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.varstaTextBox = new System.Windows.Forms.TextBox();
            this.CNPTextBox = new System.Windows.Forms.TextBox();
            this.postTextBox = new System.Windows.Forms.TextBox();
            this.numeTextBox = new System.Windows.Forms.TextBox();
            this.varstaLabel = new System.Windows.Forms.Label();
            this.dataLabel = new System.Windows.Forms.Label();
            this.CNPLabel = new System.Windows.Forms.Label();
            this.postLabel = new System.Windows.Forms.Label();
            this.numeLabel = new System.Windows.Forms.Label();
            this.adaugaJucatorbutton = new System.Windows.Forms.Button();
            this.jucatoriFlowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.detaliiJucatorGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // echipaLabel
            // 
            this.echipaLabel.AutoSize = true;
            this.echipaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.echipaLabel.Location = new System.Drawing.Point(31, 35);
            this.echipaLabel.Name = "echipaLabel";
            this.echipaLabel.Size = new System.Drawing.Size(51, 17);
            this.echipaLabel.TabIndex = 0;
            this.echipaLabel.Text = "Echipa";
            // 
            // echipeComboBox
            // 
            this.echipeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.echipeComboBox.FormattingEnabled = true;
            this.echipeComboBox.Location = new System.Drawing.Point(106, 32);
            this.echipeComboBox.Name = "echipeComboBox";
            this.echipeComboBox.Size = new System.Drawing.Size(190, 24);
            this.echipeComboBox.TabIndex = 1;
            this.echipeComboBox.SelectedIndexChanged += new System.EventHandler(this.echipeComboBox_SelectedIndexChanged);
            // 
            // adaugaEchipaButton
            // 
            this.adaugaEchipaButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adaugaEchipaButton.Location = new System.Drawing.Point(317, 30);
            this.adaugaEchipaButton.Name = "adaugaEchipaButton";
            this.adaugaEchipaButton.Size = new System.Drawing.Size(117, 26);
            this.adaugaEchipaButton.TabIndex = 2;
            this.adaugaEchipaButton.Text = "Echipa noua";
            this.adaugaEchipaButton.UseVisualStyleBackColor = true;
            // 
            // detaliiJucatorGroupBox
            // 
            this.detaliiJucatorGroupBox.Controls.Add(this.dateTimePicker);
            this.detaliiJucatorGroupBox.Controls.Add(this.varstaTextBox);
            this.detaliiJucatorGroupBox.Controls.Add(this.CNPTextBox);
            this.detaliiJucatorGroupBox.Controls.Add(this.postTextBox);
            this.detaliiJucatorGroupBox.Controls.Add(this.numeTextBox);
            this.detaliiJucatorGroupBox.Controls.Add(this.varstaLabel);
            this.detaliiJucatorGroupBox.Controls.Add(this.dataLabel);
            this.detaliiJucatorGroupBox.Controls.Add(this.CNPLabel);
            this.detaliiJucatorGroupBox.Controls.Add(this.postLabel);
            this.detaliiJucatorGroupBox.Controls.Add(this.numeLabel);
            this.detaliiJucatorGroupBox.Location = new System.Drawing.Point(307, 87);
            this.detaliiJucatorGroupBox.Name = "detaliiJucatorGroupBox";
            this.detaliiJucatorGroupBox.Size = new System.Drawing.Size(387, 288);
            this.detaliiJucatorGroupBox.TabIndex = 4;
            this.detaliiJucatorGroupBox.TabStop = false;
            this.detaliiJucatorGroupBox.Text = "Detalii jucator";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Enabled = false;
            this.dateTimePicker.Location = new System.Drawing.Point(150, 172);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(195, 20);
            this.dateTimePicker.TabIndex = 16;
            // 
            // varstaTextBox
            // 
            this.varstaTextBox.Location = new System.Drawing.Point(150, 208);
            this.varstaTextBox.Name = "varstaTextBox";
            this.varstaTextBox.Size = new System.Drawing.Size(195, 20);
            this.varstaTextBox.TabIndex = 15;
            // 
            // CNPTextBox
            // 
            this.CNPTextBox.Location = new System.Drawing.Point(150, 138);
            this.CNPTextBox.Name = "CNPTextBox";
            this.CNPTextBox.Size = new System.Drawing.Size(195, 20);
            this.CNPTextBox.TabIndex = 13;
            // 
            // postTextBox
            // 
            this.postTextBox.Location = new System.Drawing.Point(150, 101);
            this.postTextBox.Name = "postTextBox";
            this.postTextBox.Size = new System.Drawing.Size(195, 20);
            this.postTextBox.TabIndex = 12;
            // 
            // numeTextBox
            // 
            this.numeTextBox.Location = new System.Drawing.Point(150, 68);
            this.numeTextBox.Name = "numeTextBox";
            this.numeTextBox.Size = new System.Drawing.Size(195, 20);
            this.numeTextBox.TabIndex = 11;
            // 
            // varstaLabel
            // 
            this.varstaLabel.AutoSize = true;
            this.varstaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.varstaLabel.Location = new System.Drawing.Point(52, 208);
            this.varstaLabel.Name = "varstaLabel";
            this.varstaLabel.Size = new System.Drawing.Size(49, 17);
            this.varstaLabel.TabIndex = 10;
            this.varstaLabel.Text = "Varsta";
            // 
            // dataLabel
            // 
            this.dataLabel.AutoSize = true;
            this.dataLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataLabel.Location = new System.Drawing.Point(52, 172);
            this.dataLabel.Name = "dataLabel";
            this.dataLabel.Size = new System.Drawing.Size(88, 17);
            this.dataLabel.TabIndex = 9;
            this.dataLabel.Text = "Data nasterii";
            // 
            // CNPLabel
            // 
            this.CNPLabel.AutoSize = true;
            this.CNPLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CNPLabel.Location = new System.Drawing.Point(52, 138);
            this.CNPLabel.Name = "CNPLabel";
            this.CNPLabel.Size = new System.Drawing.Size(36, 17);
            this.CNPLabel.TabIndex = 8;
            this.CNPLabel.Text = "CNP";
            // 
            // postLabel
            // 
            this.postLabel.AutoSize = true;
            this.postLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postLabel.Location = new System.Drawing.Point(52, 101);
            this.postLabel.Name = "postLabel";
            this.postLabel.Size = new System.Drawing.Size(36, 17);
            this.postLabel.TabIndex = 7;
            this.postLabel.Text = "Post";
            // 
            // numeLabel
            // 
            this.numeLabel.AutoSize = true;
            this.numeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numeLabel.Location = new System.Drawing.Point(52, 68);
            this.numeLabel.Name = "numeLabel";
            this.numeLabel.Size = new System.Drawing.Size(45, 17);
            this.numeLabel.TabIndex = 6;
            this.numeLabel.Text = "Nume";
            // 
            // adaugaJucatorbutton
            // 
            this.adaugaJucatorbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adaugaJucatorbutton.Location = new System.Drawing.Point(149, 349);
            this.adaugaJucatorbutton.Name = "adaugaJucatorbutton";
            this.adaugaJucatorbutton.Size = new System.Drawing.Size(117, 26);
            this.adaugaJucatorbutton.TabIndex = 5;
            this.adaugaJucatorbutton.Text = "Jucator nou";
            this.adaugaJucatorbutton.UseVisualStyleBackColor = true;
            // 
            // jucatoriFlowLayoutPanel
            // 
            this.jucatoriFlowLayoutPanel.AutoScroll = true;
            this.jucatoriFlowLayoutPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.jucatoriFlowLayoutPanel.Location = new System.Drawing.Point(34, 87);
            this.jucatoriFlowLayoutPanel.Name = "jucatoriFlowLayoutPanel";
            this.jucatoriFlowLayoutPanel.Size = new System.Drawing.Size(232, 245);
            this.jucatoriFlowLayoutPanel.TabIndex = 3;
            this.jucatoriFlowLayoutPanel.WrapContents = false;
            // 
            // LPF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 402);
            this.Controls.Add(this.adaugaJucatorbutton);
            this.Controls.Add(this.detaliiJucatorGroupBox);
            this.Controls.Add(this.jucatoriFlowLayoutPanel);
            this.Controls.Add(this.adaugaEchipaButton);
            this.Controls.Add(this.echipeComboBox);
            this.Controls.Add(this.echipaLabel);
            this.Name = "LPF";
            this.Text = "LPF";
            this.detaliiJucatorGroupBox.ResumeLayout(false);
            this.detaliiJucatorGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label echipaLabel;
        private System.Windows.Forms.ComboBox echipeComboBox;
        private System.Windows.Forms.Button adaugaEchipaButton;
        private System.Windows.Forms.GroupBox detaliiJucatorGroupBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.TextBox varstaTextBox;
        private System.Windows.Forms.TextBox CNPTextBox;
        private System.Windows.Forms.TextBox postTextBox;
        private System.Windows.Forms.TextBox numeTextBox;
        private System.Windows.Forms.Label varstaLabel;
        private System.Windows.Forms.Label dataLabel;
        private System.Windows.Forms.Label CNPLabel;
        private System.Windows.Forms.Label postLabel;
        private System.Windows.Forms.Label numeLabel;
        private System.Windows.Forms.Button adaugaJucatorbutton;
        private System.Windows.Forms.FlowLayoutPanel jucatoriFlowLayoutPanel;
    }
}

