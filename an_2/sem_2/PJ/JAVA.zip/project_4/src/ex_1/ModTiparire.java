package ex_1;

import java.io.Serializable;


/**
 * Enumerare Moduri de Tiparire
 */
enum ModTiparire implements Serializable {
    COLOR,
    ALB_NEGRU
}
