package ex_1;

import java.io.Serializable;


/**
 * Enumerare Situatie echipamente
 */
enum  Situatie implements Serializable {
    ACHIZITIONAT,
    EXPUS,
    VANDUT
}
