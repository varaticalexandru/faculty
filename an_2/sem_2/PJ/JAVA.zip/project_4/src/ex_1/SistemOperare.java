package ex_1;

import java.io.Serializable;

/**
 * Enumerare tipuri Sisteme de Operare
 */
enum SistemOperare implements Serializable {
    WINDOWS,
    LINUX
}
