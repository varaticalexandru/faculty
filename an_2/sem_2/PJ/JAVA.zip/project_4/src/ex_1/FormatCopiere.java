package ex_1;

enum FormatCopiere {
    A3,
    A4
}
