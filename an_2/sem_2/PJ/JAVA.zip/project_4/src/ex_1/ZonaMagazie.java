package ex_1;

import java.io.Serializable;


/**
 * Enumerare Zone Magazie
 */
enum ZonaMagazie implements Serializable {
    A,
    B,
    C
}
