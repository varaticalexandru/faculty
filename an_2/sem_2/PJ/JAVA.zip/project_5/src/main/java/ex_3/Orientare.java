package ex_3;

public enum Orientare {
    LUNGIME,
    LATIME,
    ORICARE
}
