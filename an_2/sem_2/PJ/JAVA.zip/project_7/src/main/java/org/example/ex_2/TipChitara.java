package org.example.ex_2;

public enum TipChitara {
    ELECTRICA,
    ACUSTICA,
    CLASICA
}
