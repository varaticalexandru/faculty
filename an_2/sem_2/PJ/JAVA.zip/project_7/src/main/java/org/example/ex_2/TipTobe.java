package org.example.ex_2;

public enum TipTobe {
    ELECTRONICE,
    ACUSTICE
}
