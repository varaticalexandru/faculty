package org.example.ex_1;

public record Carte(String titlul, String autorul, int anul) { }