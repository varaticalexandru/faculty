

-- studenta ”Elisabeta Maris” la cursul ”Sisteme electrice”
INSERT INTO Contract(nrc, sid, cid, an, semestru)
VALUES (10, 'SET001', 'CRS03', 2022, 2);

-- - studentul ”Vasile Luca” la cursul ”Sisteme electrice”
INSERT INTO Contract(nrc, sid, cid, an, semestru)
VALUES (11, 'SET002', 'CRS03', 2022, 2);

-- - studentul ”Carol Jinca” la cursul ”Echipamente electrice”
INSERT INTO Contract(nrc, sid, cid, an, semestru)
VALUES (12, 'SET003', 'CRS04', 2022, 2);


