-- Folosind comanda DELETE cu WHERE să se șteargă
-- contractul pentru studentul ”Vasile Luca” la cursul ”Sisteme 
-- electrice”.


DELETE FROM Contract
WHERE sid='SET002'