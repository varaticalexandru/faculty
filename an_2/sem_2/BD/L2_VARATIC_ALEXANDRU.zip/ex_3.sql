-- Folosind comanda UPDATE cu WHERE să se 
-- modifice numărul de locuri din sala A109 la 82

UPDATE SALA
SET Nr_locuri=82
WHERE cods='A109';